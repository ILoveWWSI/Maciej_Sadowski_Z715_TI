﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Przygody.Models;
using System.Configuration;
using System.IO;

namespace Przygody.Controllers
{
    public class WedrowkiController : Controller
    {
        private WedrowkiEntities db = new WedrowkiEntities();


        public async Task<ActionResult> Index()
        {
            return View(await db.Wedrowkas.ToListAsync());
        }


        public async Task<ActionResult> Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Wedrowka wedrowka = await db.Wedrowkas.FindAsync(id);
            if (wedrowka == null)
            {
                return HttpNotFound();
            }
            return View(wedrowka);
        }


        public ActionResult Create()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "id,Trasa,Dystans,Data,Zdjecia")] Wedrowka wedrowka, HttpPostedFileBase ImageFile)
        {
            if (ImageFile != null && ImageFile.ContentLength > 0)
            {
                var fileName = Path.GetFileName(ImageFile.FileName);
                var path = Path.Combine(Server.MapPath("~/UserImages/"), fileName);
                ImageFile.SaveAs(path);
            }

            if (ModelState.IsValid)
            {
                wedrowka.Zdjecia = new byte[ImageFile.ContentLength];
                ImageFile.InputStream.Read(wedrowka.Zdjecia, 0, ImageFile.ContentLength);

                db.Wedrowkas.Add(wedrowka);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(wedrowka);
        }

        public async Task<ActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Wedrowka wedrowka = await db.Wedrowkas.FindAsync(id);
            if (wedrowka == null)
            {
                return HttpNotFound();
            }
            return View(wedrowka);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "id,Trasa,Dystans,Data,Zdjecia")] Wedrowka wedrowka)
        {

            if (ModelState.IsValid)
            {
                db.Entry(wedrowka).State = EntityState.Modified;
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(wedrowka);
        }

   
        public async Task<ActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Wedrowka wedrowka = await db.Wedrowkas.FindAsync(id);
            if (wedrowka == null)
            {
                return HttpNotFound();
            }
            return View(wedrowka);
        }


        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            Wedrowka wedrowka = await db.Wedrowkas.FindAsync(id);
            db.Wedrowkas.Remove(wedrowka);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
