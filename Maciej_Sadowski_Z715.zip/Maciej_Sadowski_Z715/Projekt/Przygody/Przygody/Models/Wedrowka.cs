namespace Przygody.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Web;

    public partial class Wedrowka
    {
        public int id { get; set; }
        public string Trasa { get; set; }
        public string Dystans { get; set; }

        [Required(ErrorMessage = "Required")]
        [RegularExpression(@"(((0|1)[0-9]|2[0-9]|3[0-1])\/(0[1-9]|1[0-2])\/((19|20)\d\d))$", ErrorMessage = "Invalid date format.")]
        public string Data { get; set; }
        [DisplayName("Fotka")]
        public byte[] Zdjecia { get; set; }
    }
}
